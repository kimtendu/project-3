-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: school
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,'Lunea C. Farmer'),(2,'Ava B. Drake'),(3,'Dante P. Dean'),(4,'Deirdre D. Pennington'),(5,'Petra I. Reyes'),(6,'Veronica H. Alford'),(7,'Henry G. Donaldson'),(8,'Ignacia C. Ballard'),(9,'Laith O. Medina'),(10,'Ora M. Faulkner'),(11,'John S. Dean'),(12,'Flavia H. Davis'),(13,'Yolanda T. Edwards'),(14,'Karyn E. Barlow'),(15,'Nathaniel I. Gray'),(16,'Ivan C. Nguyen'),(17,'Eagan W. Townsend'),(18,'Xyla M. Moon'),(19,'Simon M. Gregory'),(20,'Mia U. Henson'),(21,'Barbara Y. Jackson'),(22,'Tanek Y. Hurley'),(23,'Rhoda W. Mcdaniel'),(24,'Cailin L. Peters'),(25,'Colorado H. Anderson'),(26,'Nehru X. Rowe'),(27,'Erin U. Jones'),(28,'Yoshi L. Nunez'),(29,'Rajah B. Combs'),(30,'Silas N. Bradford'),(31,'Aphrodite E. Coleman'),(32,'Farrah I. Walls'),(33,'Ray N. Cunningham'),(34,'Aristotle W. Mccarty'),(35,'Nero J. Herrera'),(36,'Cullen B. Abbott'),(37,'Mechelle V. Hooper'),(38,'Cassidy T. Kirk'),(39,'Joelle M. Velez'),(40,'Diana L. Page'),(41,'Geoffrey A. Hawkins'),(42,'Jayme X. Wilder'),(43,'Charity Q. Norris'),(44,'Dahlia Q. Fernandez'),(45,'Warren C. Schneider'),(46,'Kai M. Moss'),(47,'Alexander B. Aguirre'),(48,'Josephine L. Fleming'),(49,'Armand M. Booth'),(50,'Evelyn X. Obrien'),(51,'Ria M. Richardson'),(52,'Alma V. Stuart'),(53,'Dieter G. Stanton'),(54,'Jonas H. Oneil'),(55,'Cassidy A. Cohen'),(56,'Adria R. Moran'),(57,'Hedy X. Meadows'),(58,'Fredericka G. Fox'),(59,'Carly F. Pope'),(60,'McKenzie L. Wallace'),(61,'Gage E. Sutton'),(62,'Bell G. Harper'),(63,'Bree I. Alexander'),(64,'Tiger K. Valenzuela'),(65,'Brendan Q. Chapman'),(66,'Ishmael P. Owens'),(67,'Jack H. Tucker'),(68,'Jillian A. Ewing'),(69,'Jolene T. Oneil'),(70,'Uriel V. Keith'),(71,'Imani K. Wells'),(72,'Althea M. Richardson'),(73,'Cassady B. Glover'),(74,'Rose V. Rojas'),(75,'Candice P. Avila'),(76,'Whoopi P. Osborn'),(77,'Sopoline X. Young'),(78,'Hayes V. Cameron'),(79,'Regan Z. Tanner'),(80,'Armand F. Sloan'),(81,'Isabella W. Washington'),(82,'Craig I. Raymond'),(83,'Karyn B. Hatfield'),(84,'Tobias E. Williams'),(85,'Darryl H. Warner'),(86,'Adrienne C. Morgan'),(87,'Shannon C. Ford'),(88,'Driscoll Y. Hester'),(89,'Madeline W. Gomez'),(90,'Reece U. Lott'),(91,'Yen N. Pacheco'),(92,'Karly E. Moody'),(93,'Stephen G. Fry'),(94,'Baxter M. Webster'),(95,'Charissa A. Long'),(96,'Marsden M. Berger'),(97,'Dexter V. Davenport'),(98,'Stephanie L. Greer'),(99,'Keefe L. Wright'),(100,'Nevada K. Jarvis');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-29 17:15:02
