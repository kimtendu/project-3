-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: school
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `img` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'fullstack',NULL,NULL),(2,'java',NULL,NULL),(3,'Charles','ultrices. Vivamus rhoncus. Donec est. Nunc ul','Euismod Et Associates'),(4,'Richard','magna. Praesent interdum ligula eu enim. Etia','Sollicitudin A Malesuada Limited'),(5,'Clark','Vivamus non lorem vitae odio sagittis semper.','Dolor Associates'),(6,'Chester','Maecenas libero est, congue a, aliquet vel, v','Sed Pede Ltd'),(7,'Mason','enim. Curabitur massa. Vestibulum accumsan ne','Ornare Lectus Associates'),(8,'Marsden','sapien. Cras dolor dolor, tempus non, lacinia','Risus Quisque Company'),(9,'Keith','amet orci. Ut sagittis lobortis mauris. Suspe','Cursus Industries'),(10,'Curran','Morbi sit amet massa. Quisque porttitor eros ','Sit Amet Orci Company'),(11,'Nehru','eros. Nam consequat dolor vitae dolor. Donec ','Nunc In At Associates'),(12,'Nicholas','Donec consectetuer mauris id sapien. Cras dol','Velit Eu Sem Industries'),(13,'Colorado','dolor elit, pellentesque a, facilisis non, bi','Ultrices Mauris Company'),(14,'Isaac','Aliquam ornare, libero at auctor ullamcorper,','Et Arcu Institute'),(15,'Linus','sociis natoque penatibus et magnis dis partur','Mauris Vestibulum Neque Foundation'),(16,'Rashad','urna justo faucibus lectus, a sollicitudin or','Eleifend Cras Institute'),(17,'Nigel','luctus lobortis. Class aptent taciti sociosqu','Dolor Quam Foundation'),(18,'Rooney','pharetra ut, pharetra sed, hendrerit a, arcu.','Non Lacinia At Company'),(19,'Valentine','magna. Phasellus dolor elit, pellentesque a, ','A Feugiat Tellus Corporation'),(20,'Castor','Nullam vitae diam. Proin dolor. Nulla semper ','Interdum Foundation'),(21,'Byron','Aenean euismod mauris eu elit. Nulla facilisi','Commodo Tincidunt Associates'),(22,'Declan','ridiculus mus. Proin vel arcu eu odio tristiq','Vitae Velit Corporation'),(23,'Marvin','lacinia orci, consectetuer euismod est arcu a','Malesuada Corporation'),(24,'Ian','eu, ultrices sit amet, risus. Donec nibh enim','Nunc Sed Company'),(25,'Steven','inceptos hymenaeos. Mauris ut quam vel sapien','A Nunc In Corp.'),(26,'Lucian','id magna et ipsum cursus vestibulum. Mauris m','Mi Company'),(27,'Brenden','dictum magna. Ut tincidunt orci quis lectus. ','Dui Semper Associates'),(28,'Ian','mattis. Integer eu lacus. Quisque imperdiet, ','Egestas Hendrerit Neque Institute'),(29,'Perry','aliquet, sem ut cursus luctus, ipsum leo elem','Quis Corporation'),(30,'Aaron','Nullam feugiat placerat velit. Quisque varius','Fermentum Corp.'),(31,'Orson','in, cursus et, eros. Proin ultrices. Duis vol','In Lobortis Limited'),(32,'Gage','rutrum magna. Cras convallis convallis dolor.','Nam Nulla Consulting'),(33,'Jack','Nulla eu neque pellentesque massa lobortis ul','Sit Amet Incorporated'),(34,'Robert','velit dui, semper et, lacinia vitae, sodales ','Sem Corporation'),(35,'Paki','Aliquam erat volutpat. Nulla facilisis. Suspe','Nunc Ltd'),(36,'Nathaniel','commodo hendrerit. Donec porttitor tellus non','A Sollicitudin Incorporated'),(37,'Barclay','Duis volutpat nunc sit amet metus. Aliquam er','Nulla Eu Neque LLC'),(38,'Octavius','ligula. Aenean gravida nunc sed pede. Cum soc','Sociis Natoque LLP'),(39,'Barrett','per inceptos hymenaeos. Mauris ut quam vel sa','Curabitur Vel Inc.'),(40,'Jordan','dui lectus rutrum urna, nec luctus felis puru','Vel Vulputate Eu LLC'),(41,'Christian','tristique senectus et netus et malesuada fame','Velit Eget Laoreet Limited'),(42,'Ali','Integer eu lacus. Quisque imperdiet, erat non','Ultricies Ornare LLP'),(43,'Hakeem','a feugiat tellus lorem eu metus. In lorem. Do','Et LLP'),(44,'Nero','diam. Duis mi enim, condimentum eget, volutpa','Tortor Dictum Eu Foundation'),(45,'Macaulay','magna tellus faucibus leo, in lobortis tellus','Erat Neque Non LLP'),(46,'Theodore','rutrum magna. Cras convallis convallis dolor.','Morbi Neque Consulting'),(47,'Robert','vestibulum, neque sed dictum eleifend, nunc r','Arcu Curabitur Consulting'),(48,'Zane','purus, in molestie tortor nibh sit amet orci.','Erat Company'),(49,'Julian','erat. Vivamus nisi. Mauris nulla. Integer urn','Luctus Lobortis PC'),(50,'Leroy','feugiat placerat velit. Quisque varius. Nam p','Sit Amet Corporation'),(51,'Rudyard','molestie tortor nibh sit amet orci. Ut sagitt','Varius Et LLC'),(52,'Harlan','eu, odio. Phasellus at augue id ante dictum c','Neque Venenatis Associates'),(53,'Rigel','pede ac urna. Ut tincidunt vehicula risus. Nu','Velit Cras Company'),(54,'Lev','per conubia nostra, per inceptos hymenaeos. M','Quis Arcu Vel LLP'),(55,'Tobias','Nam porttitor scelerisque neque. Nullam nisl.','In Corp.'),(56,'Anthony','urna. Ut tincidunt vehicula risus. Nulla eget','Ad Litora Torquent Institute'),(57,'Slade','vulputate, posuere vulputate, lacus. Cras int','Montes Nascetur Limited'),(58,'Caldwell','Cras dictum ultricies ligula. Nullam enim. Se','Mollis Dui Incorporated'),(59,'Dennis','arcu. Sed et libero. Proin mi. Aliquam gravid','Pellentesque Company'),(60,'Julian','velit. Aliquam nisl. Nulla eu neque pellentes','Non Limited'),(61,'Akeem','feugiat tellus lorem eu metus. In lorem. Done','Sed Orci Lobortis Incorporated'),(62,'Malachi','malesuada vel, convallis in, cursus et, eros.','Vel Sapien Imperdiet Corp.'),(63,'Tyler','Curabitur consequat, lectus sit amet luctus v','Eget Mollis PC'),(64,'Carl','egestas a, dui. Cras pellentesque. Sed dictum','Tincidunt LLP'),(65,'Graiden','molestie. Sed id risus quis diam luctus lobor','Mattis Velit Company'),(66,'Russell','Integer eu lacus. Quisque imperdiet, erat non','Magna Lorem Limited'),(67,'Vance','Morbi non sapien molestie orci tincidunt adip','Metus Ltd'),(68,'Galvin','elit. Etiam laoreet, libero et tristique pell','Ac PC'),(69,'Howard','scelerisque sed, sapien. Nunc pulvinar arcu e','Risus Corporation'),(70,'Martin','risus. Donec egestas. Aliquam nec enim. Nunc ','Ipsum Dolor PC'),(71,'Wyatt','Cras convallis convallis dolor. Quisque tinci','Luctus Felis Purus Associates'),(72,'Armand','dolor. Fusce mi lorem, vehicula et, rutrum eu','Donec Egestas Aliquam Associates'),(73,'Talon','arcu. Vestibulum ante ipsum primis in faucibu','Risus Institute'),(74,'Grant','ut, sem. Nulla interdum. Curabitur dictum. Ph','Cubilia Curae; Phasellus LLP'),(75,'Orlando','fringilla. Donec feugiat metus sit amet ante.','Pretium Institute'),(76,'Cameron','massa rutrum magna. Cras convallis convallis ','Eu LLC'),(77,'Russell','et netus et malesuada fames ac turpis egestas','Nec Tempus PC'),(78,'Wang','nulla. Integer urna. Vivamus molestie dapibus','Mollis Phasellus Libero PC'),(79,'Rashad','faucibus leo, in lobortis tellus justo sit am','Lorem Fringilla Inc.'),(80,'Jesse','sapien, gravida non, sollicitudin a, malesuad','Et Foundation'),(81,'Brent','nec ante blandit viverra. Donec tempus, lorem','Cursus In Hendrerit Ltd'),(82,'Hoyt','egestas rhoncus. Proin nisl sem, consequat ne','A Facilisis Corporation'),(83,'Oren','tempus, lorem fringilla ornare placerat, orci','Quam Pellentesque Habitant LLP'),(84,'Zahir','lorem semper auctor. Mauris vel turpis. Aliqu','Egestas A Scelerisque Company'),(85,'Aristotle','non, egestas a, dui. Cras pellentesque. Sed d','Suspendisse Aliquet Corp.'),(86,'Gabriel','convallis ligula. Donec luctus aliquet odio. ','Fusce Incorporated'),(87,'Scott','interdum feugiat. Sed nec metus facilisis lor','Per Inceptos Corp.'),(88,'Brady','quis urna. Nunc quis arcu vel quam dignissim ','Enim Sed Associates'),(89,'Jakeem','commodo tincidunt nibh. Phasellus nulla. Inte','Nascetur Industries'),(90,'Daniel','molestie sodales. Mauris blandit enim consequ','Lorem Ipsum Sodales Industries'),(91,'Troy','Fusce mollis. Duis sit amet diam eu dolor ege','Lacus Limited'),(92,'Russell','nisi a odio semper cursus. Integer mollis. In','Magna Praesent Interdum Foundation'),(93,'Richard','Pellentesque habitant morbi tristique senectu','Lorem Associates'),(94,'Neil','Integer urna. Vivamus molestie dapibus ligula','Imperdiet Erat Institute'),(95,'Jin','Ut nec urna et arcu imperdiet ullamcorper. Du','Turpis Nec Incorporated'),(96,'Seth','congue turpis. In condimentum. Donec at arcu.','Velit Company'),(97,'Daquan','vitae, orci. Phasellus dapibus quam quis diam','Mauris Sit Institute'),(98,'Lee','molestie. Sed id risus quis diam luctus lobor','Rutrum Lorem Institute'),(99,'Cade','semper pretium neque. Morbi quis urna. Nunc q','Sodales Industries'),(100,'Cadman','ipsum. Curabitur consequat, lectus sit amet l','Donec Limited'),(101,'Ethan','ipsum primis in faucibus orci luctus et ultri','Lacinia Ltd'),(102,'Rooney','Duis ac arcu. Nunc mauris. Morbi non sapien m','Facilisis Facilisis Magna Inc.');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-29 17:15:01
